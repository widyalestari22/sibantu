<?php $__env->startSection('title', 'Edit Penerima Bantuan'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Edit Daftar Penerima Bantuan</h5>


            <form class="row g-3" action="<?php echo e(route('pengajuan.rt.update', $pengajuan->id_pengajuan)); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="col-md-6">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama"
                        placeholder="Nama Penerima" value="<?php echo e($pengajuan->nama); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="nik" class="form-label">NIK</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik"
                        placeholder="Nomor Induk Kependudukan" value="<?php echo e($pengajuan->nik); ?>">
                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="kelamin" class="form-label">Jenis Kelamin</label>
                    <select class="form-select <?php $__errorArgs = ['kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kelamin">
                        <option value="" selected disabled>Pilih Jenis kelamin</option>
                        <option value="Laki-laki" <?php echo e($pengajuan->kelamin == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki
                        </option>
                        <option value="Perempuan" <?php echo e($pengajuan->kelamin == 'Perempuan' ? 'selected' : ''); ?>>Perempuan
                        </option>
                    </select>
                    <?php $__errorArgs = ['kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat"
                        placeholder="Alamat" value="<?php echo e($pengajuan->alamat); ?>">
                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="rt" class="form-label">RT</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rt"
                        placeholder="rt" value="<?php echo e($pengajuan->rt); ?>">
                    <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="rw" class="form-label">RW</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rw"
                        placeholder="rw" value="<?php echo e($pengajuan->rw); ?>">
                    <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label for="tanggungan" class="form-label">Jumlah Tanggungan</label>
                    <input type="number" class="form-control <?php $__errorArgs = ['tanggungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggungan"
                        placeholder="tanggungan" value="<?php echo e(old('tanggungan', $pengajuan->tanggungan)); ?>">
                    <?php $__errorArgs = ['tanggungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label for="tanah" class="form-label">Ukuran Tanah</label>
                    <div class="row">
                        <div class="form-group">
                            <div class="input-group">
                                <input type="number" class="form-control <?php $__errorArgs = ['tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tanah" name="tanah" placeholder="Masukkan luas tanah"
                                    value="<?php echo e(old('tanah', $pengajuan->tanah)); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text">m²</span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                    <input type="date" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $pengajuan->tanggal_lahir)); ?>">
                    <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="penghasilan" class="form-label">Penghasilan</label>
                    <div class="form-check">
                        <input class="form-check-input <?php $__errorArgs = ['penghasilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                            name="penghasilan" id="kurang_dari_1juta" value="Kurang dari Rp 1.000.000"
                            <?php echo e($pengajuan->penghasilan == 'Kurang dari Rp 1.000.000' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="kurang_dari_1juta">
                            Kurang dari Rp 1.000.000
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input <?php $__errorArgs = ['penghasilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                            name="penghasilan" id="1juta_5juta" value="Rp 1.000.000 - Rp 5.000.000"
                            <?php echo e($pengajuan->penghasilan == 'Rp 1.000.000 - Rp 5.000.000' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="1juta_5juta">
                            Rp 1.000.000 - Rp 5.000.000
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input <?php $__errorArgs = ['penghasilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                            name="penghasilan" id="lebih_dari_5juta" value="Lebih dari Rp 5.000.000"
                            <?php echo e($pengajuan->penghasilan == 'Lebih dari Rp 5.000.000' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="lebih_dari_5juta">
                            Lebih dari Rp 5.000.000
                        </label>
                    </div>
                    <?php $__errorArgs = ['penghasilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Mendapatkan Bantuan dari Instansi Lain?</label>
                    <div class="form-check">
                        <input class="form-check-input <?php $__errorArgs = ['tanpa_bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                            name="tanpa_bantuan" id="tanpa_bantuan_ya" value="Ya"
                            <?php echo e($pengajuan->tanpa_bantuan == 'Ya' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="bantuan_ya">
                            Ya
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input <?php $__errorArgs = ['tanpa_bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                            name="tanpa_bantuan" id="tanpa_bantuan_tidak" value="Tidak"
                            <?php echo e($pengajuan->tanpa_bantuan == 'Tidak' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="bantuan_tidak">
                            Tidak
                        </label>
                    </div>
                    <?php $__errorArgs = ['tanpa_bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <legend class="col-form-label">Kepemilikan Elekronik</legend>
                    <div class="row">
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Handphone" name="elektronik[]"
                                value="Handphone" <?php if(in_array('Handphone', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Handphone">Handphone</label>
                        </div>
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Kulkas" name="elektronik[]"
                                value="Kulkas" <?php if(in_array('Kulkas', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Kulkas">
                                Kulkas
                            </label>
                        </div>
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Laptop" name="elektronik[]"
                                value="Laptop" <?php if(in_array('Laptop', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Laptop">
                                Laptop
                            </label>
                        </div>
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Mesin Cuci" name="elektronik[]"
                                value="Mesin Cuci" <?php if(in_array('Mesin Cuci', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Mesin Cuci">
                                Mesin Cuci
                            </label>
                        </div>
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Komputer" name="elektronik[]"
                                value="Komputer" <?php if(in_array('Komputer', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Komputer">
                                Komputer
                            </label>
                        </div>
                        <div class="form-check col-md-4">
                            <input class="form-check-input" type="checkbox" id="Televisi" name="elektronik[]"
                                value="Televisi" <?php if(in_array('Televisi', old('elektronik', explode(',', $pengajuan->elektronik)))): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="Televisi">
                                Televisi
                            </label>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="kk" class="form-label">Kartu Tanda Penduduk</label>
                    <div class="col-sm-12">
                        <input class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="kk"
                            name="kk">
                        <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if($pengajuan->kk): ?>
                        <p>File KK Sebelumnya: <a href="<?php echo e(asset('galeri/' . $pengajuan->kk)); ?>"
                                target="_blank"><?php echo e($pengajuan->kk); ?></a></p>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label for="ktp" class="form-label">Kartu Keluarga</label>
                    <div class="col-sm-12">
                        <input class="form-control <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="ktp"
                            name="ktp">
                        <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if($pengajuan->ktp): ?>
                        <p>File KTP Sebelumnya: <a href="<?php echo e(asset('galeri/' . $pengajuan->ktp)); ?>"
                                target="_blank"><?php echo e($pengajuan->ktp); ?></a></p>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label for="rumah" class="form-label">Tampak Rumah</label>
                    <div class="col-sm-12">
                        <input class="form-control <?php $__errorArgs = ['rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="rumah"
                            name="rumah">
                        <?php $__errorArgs = ['rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if($pengajuan->rumah): ?>
                        <p>File rumah Sebelumnya: <a href="<?php echo e(asset('galeri/' . $pengajuan->rumah)); ?>"
                                target="_blank"><?php echo e($pengajuan->rumah); ?></a></p>
                    <?php endif; ?>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form>



        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('rt.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Widya\aplikasi\sibantu\resources\views/rt/pengajuan/edit.blade.php ENDPATH**/ ?>