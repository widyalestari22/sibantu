<?php $__env->startSection('title', 'Persyaratan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Persyaratan Pengajuan BLT DD</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin.dashboard">Home</a></li>
                <li class="breadcrumb-item active">Persyaratan Pengajuan Bantuan Langsung Tunai Dana Desa</li>
            </ol>
        </nav>

    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <!-- Table with stripped rows -->
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Persyaratan</th>
                                    <th scope="col">Di Buat Pada</th>
                                    <th scope="col">Di Perbarui Pada</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $persyaratan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($per->persyaratan); ?></td>
                                        <td><?php echo e($per->updated_at->format('d-m-Y')); ?></td>
                                        <td><?php echo e($per->created_at->format('d-m-Y')); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>


    <!-- Modal Tambah Data -->
    <div class="modal fade" id="modalTambah" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Data Persyaratan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3" action="<?php echo e(route('persyaratan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Isian Form untuk Tambah Data -->

                        <div>
                            <label for="persyaratan" class="form-label">Persyaratan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['persyaratan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="persyaratan" placeholder="Persyaratan" value="<?php echo e(old('persyaratan')); ?>">
                            <?php $__errorArgs = ['persyaratan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="text-center mt-3">
                            <button type="submit" class="btn btn-primary">Tambah</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Vertically centered Modal tambah-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('rt.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Widya\aplikasi\sibantu\resources\views/rt/persyaratan/index.blade.php ENDPATH**/ ?>