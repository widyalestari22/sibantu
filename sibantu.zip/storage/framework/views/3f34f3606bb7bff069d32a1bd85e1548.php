<?php $__env->startSection('title, Penerima Bantuan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Penerima Bantuan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/staf/dashboard">Home</a></li>
                <li class="breadcrumb-item active">Penerimaan Bantuan Langsung Dana Desa</li>
            </ol>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <a href="<?php echo e(route('penerimaan.create')); ?>"> <button type="button"
                    class="btn btn-primary rounded-pill">Tambah</button></a>
            <a href="<?php echo e(route('blt.cetak')); ?>" target="_blank"> <button type="button"
                    class="btn btn-success rounded-pill">Cetak</button></a>
        </nav>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">

                    <div class="card-body">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama Penerima</th>
                                    <th scope="col">Nik</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">Desa</th>
                                    <th scope="col">Kecamatan</th>
                                    
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $penerima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($pen->nama); ?></td>
                                        <td><?php echo e($pen->nik); ?></td>
                                        <td><?php echo e($pen->alamat); ?></td>
                                        <td><?php echo e($pen->nama_desa); ?></td>
                                        <td><?php echo e($pen->nama_kecamatan); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('staf.penerimablt.detail', ['id' => $pen->id_penerima])); ?>">
                                                <button type="button" class="btn btn-info"><i
                                                        class="bi bi-eye-fill"></i></button>
                                            </a>
                                            <a href="<?php echo e(route('penerima.edit', ['id' => $pen->id_penerima])); ?>">
                                                <button type="button" class="btn btn-warning"><i
                                                        class="bi bi-pencil-square"></i></button>
                                            </a>
                                            
                                            <a href="<?php echo e(route('penerima.destroy', ['id' => $pen->id_penerima])); ?>"
                                                onclick="return confirm('Yakin ingin menghapus data ini?')">
                                                <button type="button" class="btn btn-danger"><i
                                                        class="bi bi-eraser-fill"></i></button>
                                            </a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staffdesa.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Widya\aplikasi\sibantu\resources\views/staffdesa/penerimaan/index.blade.php ENDPATH**/ ?>